import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JComponent;
import javax.swing.GroupLayout;
import java.awt.*;
import java.awt.event.*;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.io.IOException;

public class RubiksCube{
	
	//This instantiates the window the model is displayed in.
	private JFrame displayFrame = new JFrame();
	//This nested array is the model of cube. Each color has a number (0-5). The array is structured to represent the 6 sides of the cube- 
	//each made up of a row of 3 vertically stacked columns, which are each in turn 3 units high.
	private int[][][] cube = new int[6][3][3];
	//This is an array to allow for the buttons that make up the diplay to be generated in a loop instead of by hand.
	private RightSizedButton[][][] cubeDisplay = new RightSizedButton[5][3][3];
	private RightSizedButton rotateLeft = new RightSizedButton();
	private RightSizedButton rotateUp = new RightSizedButton();
	private RightSizedButton rotateRight = new RightSizedButton();
	private RightSizedButton rotateDown = new RightSizedButton();
	private RightSizedButton leftInverted = new RightSizedButton();
	private RightSizedButton right = new RightSizedButton();
	private RightSizedButton up = new RightSizedButton();
	private RightSizedButton upInverted = new RightSizedButton();
	private RightSizedButton downInverted = new RightSizedButton();
	private RightSizedButton down = new RightSizedButton();
	private RightSizedButton left = new RightSizedButton();
	private RightSizedButton rightInverted = new RightSizedButton();
	
	public RubiksCube(){
		
		//This generates the buttons that make up the display.
		for(int i = 0; i < 5; i++){
			for(int j = 0; j < 3; j++){
				for(int k = 0; k < 3; k++){
					cubeDisplay[i][j][k] = new RightSizedButton();
				}
			}
		}
		
		//These lines tell how the buttons should be layed out in the display window.
		JComponent panel = new JPanel();
		GroupLayout layout = new GroupLayout(panel);
		panel.setLayout(layout);
		
		GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
		
		hGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[4][0][0]).addComponent(cubeDisplay[4][0][1]).addComponent(cubeDisplay[4][0][2]));
		hGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[4][1][0]).addComponent(cubeDisplay[4][1][1]).addComponent(cubeDisplay[4][1][2]));
		hGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[4][2][0]).addComponent(cubeDisplay[4][2][1]).addComponent(cubeDisplay[4][2][2]));
		hGroup.addGroup(layout.createParallelGroup().addComponent(up).addComponent(rotateLeft).addComponent(downInverted));
		hGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[1][0][0]).addComponent(cubeDisplay[1][0][1]).addComponent(cubeDisplay[1][0][2]).addComponent(leftInverted).addComponent(cubeDisplay[0][0][0]).addComponent(cubeDisplay[0][0][1]).addComponent(cubeDisplay[0][0][2]).addComponent(left).addComponent(cubeDisplay[3][0][0]).addComponent(cubeDisplay[3][0][1]).addComponent(cubeDisplay[3][0][2]));
		hGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[1][1][0]).addComponent(cubeDisplay[1][1][1]).addComponent(cubeDisplay[1][1][2]).addComponent(rotateUp).addComponent(cubeDisplay[0][1][0]).addComponent(cubeDisplay[0][1][1]).addComponent(cubeDisplay[0][1][2]).addComponent(rotateDown).addComponent(cubeDisplay[3][1][0]).addComponent(cubeDisplay[3][1][1]).addComponent(cubeDisplay[3][1][2]));
		hGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[1][2][0]).addComponent(cubeDisplay[1][2][1]).addComponent(cubeDisplay[1][2][2]).addComponent(right).addComponent(cubeDisplay[0][2][0]).addComponent(cubeDisplay[0][2][1]).addComponent(cubeDisplay[0][2][2]).addComponent(rightInverted).addComponent(cubeDisplay[3][2][0]).addComponent(cubeDisplay[3][2][1]).addComponent(cubeDisplay[3][2][2]));
		hGroup.addGroup(layout.createParallelGroup().addComponent(upInverted).addComponent(rotateRight).addComponent(down));
		hGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[2][0][0]).addComponent(cubeDisplay[2][0][1]).addComponent(cubeDisplay[2][0][2]));
		hGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[2][1][0]).addComponent(cubeDisplay[2][1][1]).addComponent(cubeDisplay[2][1][2]));
		hGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[2][2][0]).addComponent(cubeDisplay[2][2][1]).addComponent(cubeDisplay[2][2][2]));
		layout.setHorizontalGroup(hGroup);
		
		GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
		
		vGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[1][0][0]).addComponent(cubeDisplay[1][1][0]).addComponent(cubeDisplay[1][2][0]));
		vGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[1][0][1]).addComponent(cubeDisplay[1][1][1]).addComponent(cubeDisplay[1][2][1]));
		vGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[1][0][2]).addComponent(cubeDisplay[1][1][2]).addComponent(cubeDisplay[1][2][2]));
		vGroup.addGroup(layout.createParallelGroup().addComponent(leftInverted).addComponent(rotateUp).addComponent(right));
		vGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[4][0][0]).addComponent(cubeDisplay[4][1][0]).addComponent(cubeDisplay[4][2][0]).addComponent(up).addComponent(cubeDisplay[0][0][0]).addComponent(cubeDisplay[0][1][0]).addComponent(cubeDisplay[0][2][0]).addComponent(upInverted).addComponent(cubeDisplay[2][0][0]).addComponent(cubeDisplay[2][1][0]).addComponent(cubeDisplay[2][2][0]));
		vGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[4][0][1]).addComponent(cubeDisplay[4][1][1]).addComponent(cubeDisplay[4][2][1]).addComponent(rotateLeft).addComponent(cubeDisplay[0][0][1]).addComponent(cubeDisplay[0][1][1]).addComponent(cubeDisplay[0][2][1]).addComponent(rotateRight).addComponent(cubeDisplay[2][0][1]).addComponent(cubeDisplay[2][1][1]).addComponent(cubeDisplay[2][2][1]));
		vGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[4][0][2]).addComponent(cubeDisplay[4][1][2]).addComponent(cubeDisplay[4][2][2]).addComponent(downInverted).addComponent(cubeDisplay[0][0][2]).addComponent(cubeDisplay[0][1][2]).addComponent(cubeDisplay[0][2][2]).addComponent(down).addComponent(cubeDisplay[2][0][2]).addComponent(cubeDisplay[2][1][2]).addComponent(cubeDisplay[2][2][2]));
		vGroup.addGroup(layout.createParallelGroup().addComponent(left).addComponent(rotateDown).addComponent(rightInverted));
		vGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[3][0][0]).addComponent(cubeDisplay[3][1][0]).addComponent(cubeDisplay[3][2][0]));
		vGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[3][0][1]).addComponent(cubeDisplay[3][1][1]).addComponent(cubeDisplay[3][2][1]));
		vGroup.addGroup(layout.createParallelGroup().addComponent(cubeDisplay[3][0][2]).addComponent(cubeDisplay[3][1][2]).addComponent(cubeDisplay[3][2][2]));
    	layout.setVerticalGroup(vGroup);
		
		//This sets the initial values of the model so that each side of the cube starts as a uniform color.
		for(int i = 0; i < 6; i++){
			for(int j = 0; j < 3; j++){
				for(int k = 0; k < 3; k++){
					cube[i][j][k] = i;
				}
			}
		}

		//This method colors each jbutton in the display according to what piece of the model said jbutton represents at the time the method is called.
		this.faceColorer();

		//These link the control buttons on the display to methods that will change the model and update the display appropriately.
		right.addActionListener(new RightButtonListener());
		rightInverted.addActionListener(new RightInvertedButtonListener());
		left.addActionListener(new LeftButtonListener());
		leftInverted.addActionListener(new LeftInvertedButtonListener());
		up.addActionListener(new UpButtonListener());
		upInverted.addActionListener(new UpInvertedButtonListener());
		down.addActionListener(new DownButtonListener());
		downInverted.addActionListener(new DownInvertedButtonListener());
		rotateUp.addActionListener(new RotateUpButtonListener());
		rotateDown.addActionListener(new RotateDownButtonListener());
		rotateRight.addActionListener(new RotateRightButtonListener());
		rotateLeft.addActionListener(new RotateLeftButtonListener());
		
		try{
			//These lines make setting the images for the control buttons easier.
			Image upArrow = ImageIO.read(getClass().getResource("up_arrow.png"));
			Image downArrow = ImageIO.read(getClass().getResource("down_arrow.png"));
			Image rightArrow = ImageIO.read(getClass().getResource("right_arrow.png"));
			Image leftArrow = ImageIO.read(getClass().getResource("left_arrow.png"));
			Image rotateLeftArrow = ImageIO.read(getClass().getResource("rotate_left_3d_arrow.png"));
			Image rotateRightArrow = ImageIO.read(getClass().getResource("rotate_right_3d_arrow.png"));
			Image rotateUpArrow = ImageIO.read(getClass().getResource("rotate_up_3d_arrow.png"));
			Image rotateDownArrow = ImageIO.read(getClass().getResource("rotate_down_3d_arrow.png"));
			// This bit -while more elegant in a loop or as a seperate subclass of RightSizeButton- 
			//was just as fast to write this way for the scope of this program. It sets the style for the control buttons on the display.
			right.setIcon(new ImageIcon(upArrow));
			right.setBackground(Color.darkGray);
			right.setMargin(new Insets(0, 0, 0, 0));
			right.setBorder(null);
			leftInverted.setIcon(new ImageIcon(upArrow));
			leftInverted.setBackground(Color.darkGray);
			leftInverted.setMargin(new Insets(0, 0, 0, 0));
			leftInverted.setBorder(null);
			left.setIcon(new ImageIcon(downArrow));
			left.setBackground(Color.darkGray);
			left.setMargin(new Insets(0, 0, 0, 0));
			left.setBorder(null);
			rightInverted.setIcon(new ImageIcon(downArrow));
			rightInverted.setBackground(Color.darkGray);
			rightInverted.setMargin(new Insets(0, 0, 0, 0));
			rightInverted.setBorder(null);
			upInverted.setIcon(new ImageIcon(rightArrow));
			upInverted.setBackground(Color.darkGray);
			upInverted.setMargin(new Insets(0, 0, 0, 0));
			upInverted.setBorder(null);
			down.setIcon(new ImageIcon(rightArrow));
			down.setBackground(Color.darkGray);
			down.setMargin(new Insets(0, 0, 0, 0));
			down.setBorder(null);
			up.setIcon(new ImageIcon(leftArrow));
			up.setBackground(Color.darkGray);
			up.setMargin(new Insets(0, 0, 0, 0));
			up.setBorder(null);
			downInverted.setIcon(new ImageIcon(leftArrow));
			downInverted.setBackground(Color.darkGray);
			downInverted.setMargin(new Insets(0, 0, 0, 0));
			downInverted.setBorder(null);
			rotateUp.setIcon(new ImageIcon(rotateUpArrow));
			rotateUp.setBackground(Color.darkGray);
			rotateUp.setMargin(new Insets(0, 0, 0, 0));
			rotateUp.setBorder(null);
			rotateDown.setIcon(new ImageIcon(rotateDownArrow));
			rotateDown.setBackground(Color.darkGray);
			rotateDown.setMargin(new Insets(0, 0, 0, 0));
			rotateDown.setBorder(null);
			rotateLeft.setIcon(new ImageIcon(rotateLeftArrow));
			rotateLeft.setBackground(Color.darkGray);
			rotateLeft.setMargin(new Insets(0, 0, 0, 0));
			rotateLeft.setBorder(null);
			rotateRight.setIcon(new ImageIcon(rotateRightArrow));
			rotateRight.setBackground(Color.darkGray);
			rotateRight.setMargin(new Insets(0, 0, 0, 0));
			rotateRight.setBorder(null);
		}
		catch(IOException a){}
		
		//This sets the style of the display window.
		Container c = displayFrame.getContentPane();
		c.add(panel, "Center");
		displayFrame.setMinimumSize(new Dimension(700, 700));
		panel.setBackground(Color.darkGray);
		displayFrame.setVisible(true);
		
	}
	//These next two methods help to make arrays comprising the model behave like a rubiks cube. Basically, the side not shown in the
	//display has to be "flipped" because of how the cube is projected onto the display. When a side goes to the "back" of the cube, it's
	//similar to going around to the underside of a conveyor belt, so a pattern would flipped 180 degrees keeping the same top down perspective.
	public int[] verticalFlipper(int[] a){
		int[] result = new int[3];
		int j = 2;
		for(int i = 0; i < 3; i++){
			result[i] = a[j];
			j = j - 1;
		}
		return result;
	}
		
	public int[] horizontalFlipper(int[][] a, int b){
		int[] result = new int[3];
		int j = 2;
		for(int i = 0; i < 3; i++){
			result[i]  = a[j][b];
			j = j - 1;
		}
		return result;
	}	
		
	//This method will rotate a column of the model vertically by swapping the values of the columns given to it based on the order they're given.
	public void rotateVertically(int a, int b, int c, int d, int e){
		int[] savedColumn = new int[3];
		System.arraycopy(cube[a][e], 0, savedColumn, 0, savedColumn.length);
		System.arraycopy(cube[b][e], 0, cube[a][e], 0, cube[a][e].length);
		System.arraycopy(this.verticalFlipper(cube[c][e]), 0, cube[b][e], 0, cube[b][e].length);
		System.arraycopy(this.verticalFlipper(cube[d][e]), 0, cube[c][e], 0, cube[c][e].length);
		System.arraycopy(savedColumn, 0, cube[d][e], 0, cube[d][e].length);
	}
	//This method will rotate a row of the model horizontally by swapping the values of the rows given to it based on the order they're given.
	public void rotateHorizontally(int a, int b, int c, int d, int e){
		int[] savedRow = new int[3];
		int[] savedBackRow = new int[3];
		int[] savedToBackRow = new int[3];
		System.arraycopy(this.horizontalFlipper(cube[c], e), 0, savedBackRow, 0, savedBackRow.length);
		System.arraycopy(this.horizontalFlipper(cube[d], e), 0, savedToBackRow, 0, savedToBackRow.length);
		for(int i = 0; i < 3; i++){
			savedRow[i] = cube[a][i][e];
			cube[a][i][e] = cube[b][i][e];
			cube[b][i][e] = savedBackRow[i];
			cube[c][i][e] = savedToBackRow[i];
			cube[d][i][e] = savedRow[i];
		}
	}
	//These two functions rotate the model accordingly from the perspective of looking straight on at the center face in the display.
	public void rotateClockwise(int a){
		int[][] savedFace = new int[3][3];
		System.arraycopy(cube[a][0], 0, savedFace[0], 0, savedFace[0].length);
		System.arraycopy(cube[a][1], 0, savedFace[1], 0, savedFace[1].length);
		System.arraycopy(cube[a][2], 0, savedFace[2], 0, savedFace[2].length);
		cube[a][0][0] = savedFace[0][2];
		cube[a][0][1] = savedFace[1][2];
		cube[a][0][2] = savedFace[2][2];
		cube[a][1][0] = savedFace[0][1];
		cube[a][1][2] = savedFace[2][1];
		cube[a][2][0] = savedFace[0][0];
		cube[a][2][1] = savedFace[1][0];
		cube[a][2][2] = savedFace[2][0];
	}
	
	public void rotateCounterClockwise(int a){
		int[][] savedFace = new int[3][3];
		System.arraycopy(cube[a][0], 0, savedFace[0], 0, savedFace[0].length);
		System.arraycopy(cube[a][1], 0, savedFace[1], 0, savedFace[1].length);
		System.arraycopy(cube[a][2], 0, savedFace[2], 0, savedFace[2].length);
		cube[a][0][0] = savedFace[2][0];
		cube[a][0][1] = savedFace[1][0];
		cube[a][0][2] = savedFace[0][0];
		cube[a][1][0] = savedFace[2][1];
		cube[a][1][2] = savedFace[0][1];
		cube[a][2][0] = savedFace[2][2];
		cube[a][2][1] = savedFace[1][2];
		cube[a][2][2] = savedFace[0][2];
	}
	
	 //This method colors each jbutton in the display according to what piece of the model said jbutton represents at the time the method is called.	
     public void faceColorer(){
		for(int i = 0; i < 5; i++){
			for(int j = 0; j < 3; j++){
				for(int k = 0; k < 3; k++){
					if (cube[i][j][k] == 0){
						cubeDisplay[i][j][k].setBackground(Color.green);
					}
					else if (cube[i][j][k] == 1){
						cubeDisplay[i][j][k].setBackground(Color.white);
					}
					else if (cube[i][j][k] == 2){
						cubeDisplay[i][j][k].setBackground(Color.red);
					}
					else if (cube[i][j][k] == 3){
						cubeDisplay[i][j][k].setBackground(Color.yellow);
					}
					else if (cube[i][j][k] == 4){
						cubeDisplay[i][j][k].setBackground(Color.orange);
					}
					else if (cube[i][j][k] == 5){
						cubeDisplay[i][j][k].setBackground(Color.blue);
					}
				}
			}
		}
	}
	
	//This defines the size of the buttons on the display.
	public class RightSizedButton extends JButton{
		public RightSizedButton(){
			this.setMinimumSize(new Dimension(60, 60));
		}
	}
	
	//These methods define how each control button will change the model and update the display.
	public class RightButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateVertically(0, 3, 5, 1, 2);
			RubiksCube.this.rotateClockwise(2);
			RubiksCube.this.faceColorer();
		}
    }
    
    public class RightInvertedButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateVertically(0, 1, 5, 3, 2);
			RubiksCube.this.rotateCounterClockwise(2);
			RubiksCube.this.faceColorer();
		}
    }
    
    public class LeftButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateVertically(0, 1, 5, 3, 0);
			RubiksCube.this.rotateClockwise(4);
			RubiksCube.this.faceColorer();
		}
    } 
    
    public class LeftInvertedButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateVertically(0, 3, 5, 1, 0);
			RubiksCube.this.rotateCounterClockwise(4);
			RubiksCube.this.faceColorer();
		}
    }
    
    
    public class UpButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateHorizontally(0, 2, 5, 4, 0);
			RubiksCube.this.rotateClockwise(1);
			RubiksCube.this.faceColorer();
		}
    } 

	public class UpInvertedButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateHorizontally(0, 4, 5, 2, 0);
			RubiksCube.this.rotateCounterClockwise(1);
			RubiksCube.this.faceColorer();
		}
    }
    
    public class DownButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateHorizontally(0, 4, 5, 2, 2);
			RubiksCube.this.rotateClockwise(3);
			RubiksCube.this.faceColorer();
		}
    } 
    
    public class DownInvertedButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateHorizontally(0, 2, 5, 4, 2);
			RubiksCube.this.rotateCounterClockwise(3);
			RubiksCube.this.faceColorer();
		}
    }

	public class RotateUpButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateClockwise(2);
			RubiksCube.this.rotateCounterClockwise(4);
			RubiksCube.this.rotateVertically(0, 3, 5, 1, 0);
			RubiksCube.this.rotateVertically(0, 3, 5, 1, 1);
			RubiksCube.this.rotateVertically(0, 3, 5, 1, 2);
			RubiksCube.this.faceColorer();
		}
    }


	public class RotateDownButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateClockwise(4);
			RubiksCube.this.rotateCounterClockwise(2);
			RubiksCube.this.rotateVertically(0, 1, 5, 3, 0);
			RubiksCube.this.rotateVertically(0, 1, 5, 3, 1);
			RubiksCube.this.rotateVertically(0, 1, 5, 3, 2);
			RubiksCube.this.faceColorer();
		}
    }
    
    public class RotateRightButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateClockwise(3);
			RubiksCube.this.rotateCounterClockwise(1);
			RubiksCube.this.rotateHorizontally(0, 4, 5, 2, 0);
			RubiksCube.this.rotateHorizontally(0, 4, 5, 2, 1);
			RubiksCube.this.rotateHorizontally(0, 4, 5, 2, 2);
			RubiksCube.this.faceColorer();
		}
    }
    
    public class RotateLeftButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent a){
			RubiksCube.this.rotateClockwise(1);
			RubiksCube.this.rotateCounterClockwise(3);
			RubiksCube.this.rotateHorizontally(0, 2, 5, 4, 0);
			RubiksCube.this.rotateHorizontally(0, 2, 5, 4, 1);
			RubiksCube.this.rotateHorizontally(0, 2, 5, 4, 2);
			RubiksCube.this.faceColorer();
		}
    }
    
	public static void main(String[]args){	
		new RubiksCube();
	}
}
